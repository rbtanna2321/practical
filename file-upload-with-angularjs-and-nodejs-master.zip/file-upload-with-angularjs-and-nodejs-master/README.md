# file-upload-with-angularjs-and-nodejs
File Upload using Angular and Node

Complete Tutorial: http://code.ciphertrick.com/2015/12/07/file-upload-with-angularjs-and-nodejs/ </br>
Demo Link: https://youtu.be/6XRi--KHN7U

##Quick Setup
<ul>
	<li>Download the code from here OR clone our repository by running <kbd>git clone https://github.com/rahil471/file-upload-with-angularjs-and-nodejs.git</kbd></li>	
        <li>Navigate to the server directory in our app using command-line.</li>
	<li>Run <kbd>npm install</kbd></li>
	<li>If you use gulp run <kbd>gulp</kbd> OR simply run <kbd>node app.js</kbd></li>
	<li>Open <kbd>http://localhost:3000</kbd> in your browser</li>
</ul>
